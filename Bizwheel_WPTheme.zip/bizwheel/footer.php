<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Bizwheel
 */

?>
    <?php global $bizwheel; ?>
    
	<footer class="footer" style="background-color:<?php echo esc_html( $bizwheel['footer-background-color'] ); ?>;background-image:url('<?php echo esc_html( $bizwheel['footer-background-image']['background-image']); ?>');background-repeat:<?php echo esc_html( $bizwheel['footer-background-image']['background-repeat']); ?>;background-position:<?php echo esc_html( $bizwheel['footer-background-image']['background-position']); ?>;background-size:<?php echo esc_html( $bizwheel['footer-background-image']['background-size']); ?>;background-attachment:<?php echo esc_html( $bizwheel['footer-background-image']['background-attachment']); ?>">
		<!-- Footer Top -->
		<div class="footer-top">
			<div class="container">
				<div class="row">
                    <?php dynamic_sidebar('footer-sidebar'); ?>
				</div>
				<div class="row">
					<div class="col-lg-6 offset-lg-3 col-md-8 offset-md-2 col-12">
						<!-- Footer Newsletter -->
						<div class="footer-newsletter">
							<?php dynamic_sidebar('footer-bottom'); ?>
						</div>
						<!--/ End Footer Newsletter -->
					</div>
				</div>
			</div>
		</div>
		<!-- Copyright -->
		<div class="copyright">
			<div class="container">
				<div class="row">
					<div class="col-12">
						<div class="copyright-content">
							<!-- Copyright Text -->
							<?php $allowed_html = [
                            'a'      => [
                            'href'  => [],
                            'title' => [],
                            ],
                            'br'     => [],
                            'em'     => [],
                            'strong' => [],
                            ];
                            ?>
							<p><?php echo wp_kses( $bizwheel['copyright-text'], $allowed_html );  ?></p>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!--/ End Copyright -->
	</footer><!-- #colophon -->
</div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>
