<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Bizwheel
 */

?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1" shrink-to-fit="no">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name='copyright' content='pavilan'>
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<link rel="profile" href="https://gmpg.org/xfn/11">
	<style type="text/css">
	<?php global $bizwheel; ?>	
    <?php echo esc_attr( $bizwheel['custom-css'] ); ?>
	</style>

	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?> id="bg">
<?php wp_body_open(); ?>
<div id="page" class="site">
	<a class="skip-link screen-reader-text" href="#primary"><?php esc_html_e( 'Skip to content', 'bizwheel' ); ?></a>
    
    <?php if( $bizwheel['enable-preloader'] == 1 ) : ?>
	<!-- Preloader -->
	<div class="preeloader">
		<div class="preloader-spinner"></div>
	</div>
	<!--/ End Preloader -->
	<?php endif; ?>

	<header id="masthead" class="header site-header">

		<?php get_template_part( 'template-parts/content', 'topbar' ); ?>

		<!-- Middle Header -->
		<div class="middle-header">
			<div class="container">
				<div class="row">
					<div class="col-12">
						<div class="middle-inner">
							<div class="row">
								<div class="col-lg-3 col-md-3 col-12">
									<!-- Logo -->
									<div class="logo">
										<!-- Image Logo -->
										<div class="img-logo">
											<?php the_custom_logo(); ?>
										</div>
									</div>								
									<div class="mobile-nav"></div>
									    <div class="site-branding">
											<?php
											if ( is_front_page() && is_home() ) :
												?>
												<h3 class="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></h3>
												<?php
											else :
												?>
												<p class="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></p>
												<?php
											endif;
											$bizwheel_description = get_bloginfo( 'description', 'display' );
											if ( $bizwheel_description || is_customize_preview() ) :
												?>
												<p class="site-description"><?php echo esc_html( $bizwheel_description ); ?></p>
											<?php endif; ?>
										</div><!-- .site-branding -->
								</div>
								<div class="col-lg-9 col-md-9 col-12">
									<div class="menu-area">
										<!-- Main Menu -->
										<nav class="navbar navbar-expand-lg">
											<div class="navbar-collapse">	
												<div class="nav-inner">	
													<div class="menu-home-menu-container">
														<!-- Naviagiton -->
														<?php
						                                    wp_nav_menu(array(
						                                        'theme_location' => 'primary-menu',
						                                        'fallback_cb'    => 'default_primary_menu',
						                                        'depth'          => 3,
						                                        'container'      =>  '',
						                                        'menu_class'     => 'nav main-menu menu navbar-nav',
						                                        'menu_id'        =>  'nav'
						                                    )); 
						                                ?>
														<!--/ End Naviagiton -->
													</div>
												</div>
											</div>
										</nav>
										<!--/ End Main Menu -->	
										<!-- Right Bar -->
										<div class="right-bar">
											<!-- Search Bar -->
											<ul class="right-nav">
												<li class="top-search"><a href="#0"><i class="fa fa-search"></i></a></li>
												<?php if( $bizwheel['sidebar-popup-show-hide'] == 1 ) : ?>
												    <li class="bar"><a class="fa fa-bars"></a></li>
											    <?php endif; ?>
											</ul>
											<!--/ End Search Bar -->
											<!-- Search Form -->
											<div class="search-top">
												<form role="search" action="<?php echo esc_url( home_url() ); ?>" class="search-form" method="get">
													<input type="text" name="s" value="" placeholder="Search here"/>
													<button type="submit" class="search-submit" id="searchsubmit"><i class="fa fa-search"></i></button>
												</form>
											</div>
											<!--/ End Search Form -->
										</div>	
										<!--/ End Right Bar -->
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!--/ End Middle Header -->

		<?php get_template_part( 'template-parts/content', 'sidebar-popup' ); ?>

	</header><!-- #masthead -->
