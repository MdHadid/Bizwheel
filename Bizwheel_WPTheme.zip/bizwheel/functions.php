<?php
/**
 * BizWheel functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package Bizwheel
 */

if ( ! defined( '_S_VERSION' ) ) {
	define( '_S_VERSION', '1.0.0' );
}

if ( ! function_exists( 'bizwheel_setup' ) ) :

	function bizwheel_setup() {

		load_theme_textdomain( 'bizwheel', get_template_directory() . '/languages' );

		add_theme_support( 'automatic-feed-links' );

		add_theme_support( 'title-tag' );

		add_theme_support( 'post-thumbnails' );

		register_nav_menus(
			array(
				'primary-menu' => esc_html__( 'Primary', 'bizwheel' ),
				'company-menu' => esc_html__( 'Company', 'bizwheel' ),
				'important-menu' => esc_html__( 'Important Links', 'bizwheel' )
			) );

		add_theme_support(
			'html5',
			array(
				'search-form',
				'comment-form',
				'comment-list',
				'gallery',
				'caption',
				'style',
				'script',
			)
		);

		add_theme_support(
			'custom-background',
			apply_filters(
				'bizwheel_custom_background_args',
				array(
					'default-color' => 'ffffff',
					'default-image' => '',
				)
			)
		);

		add_theme_support( 'customize-selective-refresh-widgets' );

		/**
		 * Add support for core custom logo.
		 *
		 * @link https://codex.wordpress.org/Theme_Logo
		 */
		add_theme_support(
			'custom-logo',
			array(
				'height'      => 250,
				'width'       => 250,
				'flex-width'  => true,
				'flex-height' => true,
			)
		);
	}
endif;
add_action( 'after_setup_theme', 'bizwheel_setup' );

function default_primary_menu() {

    echo '<ul id="nav" class="nav main-menu menu navbar-nav">';
    
    if ( is_user_logged_in() ) {
        echo '<li><a href="'.esc_url( home_url() ).'/wp-admin/nav-menus.php">Create a menu</a></li>';
    }
    
    else {
        echo '<li><a href="'.esc_url( home_url( '/' ) ).'">Home</a></li>';
    }

    echo '</ul>';
}

function bizwheel_content_width() {
	$GLOBALS['content_width'] = apply_filters( 'bizwheel_content_width', 640 );
}
add_action( 'after_setup_theme', 'bizwheel_content_width', 0 );

function read_more($limit) {
  $post_content = explode(' ' , get_the_content()); 
  $less_content = array_slice($post_content, 0, $limit);
  echo implode(' ', $less_content);
}

/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function bizwheel_widgets_init() {
	register_sidebar(
		array(
			'name'          => esc_html__( 'Default Sidebar', 'bizwheel' ),
			'id'            => 'default-sidebar',
			'description'   => esc_html__( 'Add widgets here.', 'bizwheel' ),
			'before_title'  => '<h3 class="widget-title">',
			'after_title'   => '</h3>'
		)
	);

	register_sidebar(
		array(
			'name'          => esc_html__( 'Footer Sidebar', 'bizwheel' ),
			'id'            => 'footer-sidebar',
			'description'   => esc_html__( 'Add widgets here.', 'bizwheel' ),
			'before_title'  => '<h3 class="widget-title">',
			'after_title'   => '</h3>'
		)
	);

	register_sidebar(
		array(
			'name'          => esc_html__( 'Footer Bottom', 'bizwheel' ),
			'id'            => 'footer-bottom',
			'description'   => esc_html__( 'Add widgets here.', 'bizwheel' )
		)
	);
}
add_action( 'widgets_init', 'bizwheel_widgets_init' );

/**
 * Enqueue scripts and styles.
 */
function bizwheel_scripts() {
	wp_enqueue_style( 'bizwheel-webfont', 'https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap' );

	wp_enqueue_style( 'bizwheel-animate-css', get_template_directory_uri() . '/assets/css/animate.min.css' );
	wp_enqueue_style( 'bizwheel-bootstrap-css', get_template_directory_uri() . '/assets/css/bootstrap.min.css' );
	wp_enqueue_style( 'bizwheel-cubeportfolio-css', get_template_directory_uri() . '/assets/css/cubeportfolio.min.css' );
	wp_enqueue_style( 'bizwheel-fontawesome', get_template_directory_uri() . '/assets/css/font-awesome.css' );
	wp_enqueue_style( 'bizwheel-jquery-fancybox-css', get_template_directory_uri() . '/assets/css/jquery.fancybox.min.css' );
	wp_enqueue_style( 'bizwheel-magnific-popup-css', get_template_directory_uri() . '/assets/css/magnific-popup.min.css' );
	wp_enqueue_style( 'bizwheel-owl-carousel-css', get_template_directory_uri() . '/assets/css/owl-carousel.min.css' );
	wp_enqueue_style( 'bizwheel-slicknav-css', get_template_directory_uri() . '/assets/css/slicknav.min.css' );

	wp_enqueue_style( 'bizwheel-resets', get_template_directory_uri() . '/assets/css/reset.css' );
	wp_enqueue_style( 'bizwheel-style', get_stylesheet_uri(), array(), _S_VERSION );
	wp_enqueue_style( 'bizwheel-responsive', get_template_directory_uri() . '/assets/css/responsive.css' );
    
    wp_enqueue_script( 'bizwheel-jquery', get_template_directory_uri() . '/assets/js/jquery.min.js', array(), _S_VERSION, true );
    wp_enqueue_script( 'bizwheel-jquery-migrate', get_template_directory_uri() . '/assets/js/jquery-migrate-3.0.0.js', array(), _S_VERSION, true );
    wp_enqueue_script( 'bizwheel-popper-js', get_template_directory_uri() . '/assets/js/popper.min.js', array(), _S_VERSION, true );
    wp_enqueue_script( 'bizwheel-bootstrap-js', get_template_directory_uri() . '/assets/js/bootstrap.min.js', array(), _S_VERSION, true );
    wp_enqueue_script( 'bizwheel-modernizr-js', get_template_directory_uri() . '/assets/js/modernizr.min.js', array(), _S_VERSION, true );
    wp_enqueue_script( 'bizwheel-scrollup-js', get_template_directory_uri() . '/assets/js/scrollup.js', array(), _S_VERSION, true );
    wp_enqueue_script( 'bizwheel-jquery-fancybox-js', get_template_directory_uri() . '/assets/js/jquery-fancybox.min.js', array(), _S_VERSION, true );
    wp_enqueue_script( 'bizwheel-cubeportfolio-js', get_template_directory_uri() . '/assets/js/cubeportfolio.min.js', array(), _S_VERSION, true );
    wp_enqueue_script( 'bizwheel-slicknav-js', get_template_directory_uri() . '/assets/js/slicknav.min.js', array(), _S_VERSION, true );
    wp_enqueue_script( 'bizwheel-owl-carousel-js', get_template_directory_uri() . '/assets/js/owl-carousel.min.js', array(), _S_VERSION, true );
    wp_enqueue_script( 'bizwheel-easing-js', get_template_directory_uri() . '/assets/js/easing.js', array(), _S_VERSION, true );
    wp_enqueue_script( 'bizwheel-magnific-popup-js', get_template_directory_uri() . '/assets/js/magnific-popup.min.js', array(), _S_VERSION, true );
    wp_enqueue_script( 'bizwheel-active-js', get_template_directory_uri() . '/assets/js/active.js', array(), _S_VERSION, true );

	wp_enqueue_script( 'bizwheel-navigation', get_template_directory_uri() . '/assets/js/navigation.js', array(), _S_VERSION, true );

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'bizwheel_scripts' );

/**
 * Implement the Custom Header feature.
 */
require get_template_directory() . '/inc/custom-header.php';

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Functions which enhance the theme by hooking into WordPress.
 */
require get_template_directory() . '/inc/template-functions.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer.php';

/**
 * Load Jetpack compatibility file.
 */
if ( defined( 'JETPACK__VERSION' ) ) {
	require get_template_directory() . '/inc/jetpack.php';
}

/**
 * Include require & recommended plugin file.
 */
require get_template_directory() . '/inc/tgmpa/init.php';

/**
 * Import demo data.
 */
function ocdi_import_files() {
    return array(
        array(
            'import_file_name'           => 'Demo Import 1',
            'categories'                 => array( 'Category 1', 'Category 2' ),
            'import_file_url'            => get_template_directory_uri() . '/inc/demo/bizwheel.xml',
            'import_widget_file_url'     => get_template_directory_uri() . '/inc/demo/bizwheel.wie',
            'import_customizer_file_url' => get_template_directory_uri() . '/inc/demo/bizwheel.dat',
            'import_redux'               => array(
                array(
                    'file_url'    => get_template_directory_uri() . '/inc/demo/bizwheel.json',
                    'option_name' => 'bizwheel',
                ),
            ),
            'import_notice'              => __( 'After you import this demo, you will have to setup missing settings or media separately.', 'bizwheel' ),
        ),
    );
}
add_filter( 'pt-ocdi/import_files', 'ocdi_import_files' );
