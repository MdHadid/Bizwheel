<?php global $bizwheel; ?>

<!-- Sidebar Popup -->
<div class="sidebar-popup">
	<div class="cross">
		<a class="btn"><i class="fa fa-close"></i></a>
	</div>
	<div class="single-content">
		    <h4><?php echo esc_html( $bizwheel['sidebar-popup-title'] ); ?></h4>
		    <p><?php echo esc_html( $bizwheel['sidebar-popup-content'] ); ?></p>

        <?php if( $bizwheel['sidebar-popup-social'] == 1 ) : ?>
		<!-- Social Icons -->
		<ul class="social">
			<?php if( $bizwheel['social-links']['1'] ) : ?>
                <li><a href="<?php echo esc_url( $bizwheel['social-links']['1'] ); ?>" class="facebook"><i class="fa fa-facebook"></i></a></li>
            <?php endif; ?>
            <?php if( $bizwheel['social-links']['2'] ) : ?>
                <li><a href="<?php echo esc_url( $bizwheel['social-links']['2'] ); ?>" class="twitter"><i class="fa fa-twitter"></i></a></li>
            <?php endif; ?>
            <?php if( $bizwheel['social-links']['3'] ) : ?>
                <li><a href="<?php echo esc_url( $bizwheel['social-links']['3'] ); ?>" class="linkedin"><i class="fa fa-linkedin"></i></a></li>
            <?php endif; ?>
            <?php if( $bizwheel['social-links']['4'] ) : ?>
                <li><a href="<?php echo esc_url( $bizwheel['social-links']['4'] ); ?>" class="pinterest"><i class="fa fa-pinterest-p"></i></a></li>
            <?php endif; ?>
            <?php if( $bizwheel['social-links']['5'] ) : ?>
                <li><a href="<?php echo esc_url( $bizwheel['social-links']['5'] ); ?>" class="instagram"><i class="fa fa-instagram"></i></a></li><br/>
            <?php endif; ?>
            <?php if( $bizwheel['social-links']['6'] ) : ?>
                <li><a href="<?php echo esc_url( $bizwheel['social-links']['6'] ); ?>" class="youtube"><i class="fa fa-youtube"></i></a></li>
            <?php endif; ?>
            <?php if( $bizwheel['social-links']['7'] ) : ?>
                <li><a href="<?php echo esc_url( $bizwheel['social-links']['7'] ); ?>" class="skype"><i class="fa fa-skype"></i></a></li>
            <?php endif; ?>
            <?php if( $bizwheel['social-links']['8'] ) : ?>
                <li><a href="<?php echo esc_url( $bizwheel['social-links']['8'] ); ?>" class="google"><i class="fa fa-google-plus"></i></a></li>
            <?php endif; ?>
            <?php if( $bizwheel['social-links']['9'] ) : ?>
                <li><a href="<?php echo esc_url( $bizwheel['social-links']['9'] ); ?>" class="dribbble"><i class="fa fa-dribbble"></i></a></li>
            <?php endif; ?>
            <?php if( $bizwheel['social-links']['10'] ) : ?>
                <li><a href="<?php echo esc_url( $bizwheel['social-links']['10'] ); ?>" class="tumblr"><i class="fa fa-tumblr"></i></a></li>
            <?php endif; ?>
		</ul>
	    <?php endif; ?>
	</div>
	<?php if( $bizwheel['sidebar-popup-menu'] == 1 ) : ?>
	<div class="single-content">
		<h4><?php echo esc_html( $bizwheel['sidebar-popup-menu-title'] ); ?></h4>
		<?php wp_nav_menu( array(
            'theme_location' => 'important-menu',
            'menu_class' => 'links'
		) ); ?>   
	</div>	
    <?php endif; ?>
</div>
<!--/ End Sidebar Popup -->
