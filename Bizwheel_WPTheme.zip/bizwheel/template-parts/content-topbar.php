<?php global $bizwheel; ?>
<?php if( $bizwheel['top-bar-show-hide'] == 1 ) : ?>
<!-- Topbar -->
<div class="topbar">
	<div class="container">
		<div class="row">
			<div class="col-lg-8 col-12">
				<!-- Top Contact -->
				<div class="top-contact">
					<?php if( $bizwheel['top-bar-phone'] ) : ?>
					    <div class="single-contact"><i class="fa fa-phone"></i><?php echo esc_html( $bizwheel['top-bar-phone'] ); ?></div> 
				    <?php endif; ?>
				    <?php if( $bizwheel['top-bar-email'] ) : ?>
					    <div class="single-contact"><i class="fa fa-envelope-open"></i><?php echo esc_html( $bizwheel['top-bar-email'] ); ?></div>	
					<?php endif; ?>
					<?php if( $bizwheel['top-bar-time'] ) : ?>
					    <div class="single-contact"><i class="fa fa-clock-o"></i><?php echo esc_html( $bizwheel['top-bar-time'] ); ?></div> 
					<?php endif; ?>
				</div>
				<!-- End Top Contact -->
			</div>	
			<div class="col-lg-4 col-12">
				<div class="topbar-right">
					<?php if( $bizwheel['top-bar-show-social'] == 1 ) : ?>
					<!-- Social Icons -->
					<ul class="social-icons">
						<?php if( $bizwheel['social-links']['1'] ) : ?>
                            <li><a href="<?php echo esc_url( $bizwheel['social-links']['1'] ); ?>" class="facebook"><i class="fa fa-facebook"></i></a></li>
                        <?php endif; ?>
                        <?php if( $bizwheel['social-links']['2'] ) : ?>
                            <li><a href="<?php echo esc_url( $bizwheel['social-links']['2'] ); ?>" class="twitter"><i class="fa fa-twitter"></i></a></li>
                        <?php endif; ?>
                        <?php if( $bizwheel['social-links']['3'] ) : ?>
                            <li><a href="<?php echo esc_url( $bizwheel['social-links']['3'] ); ?>" class="linkedin"><i class="fa fa-linkedin"></i></a></li>
                        <?php endif; ?>
                        <?php if( $bizwheel['social-links']['4'] ) : ?>
                            <li><a href="<?php echo esc_url( $bizwheel['social-links']['4'] ); ?>" class="pinterest"><i class="fa fa-pinterest-p"></i></a></li>
                        <?php endif; ?>
                        <?php if( $bizwheel['social-links']['5'] ) : ?>
                            <li><a href="<?php echo esc_url( $bizwheel['social-links']['5'] ); ?>" class="instagram"><i class="fa fa-instagram"></i></a></li><br/>
                        <?php endif; ?>
                        <?php if( $bizwheel['social-links']['6'] ) : ?>
                            <li><a href="<?php echo esc_url( $bizwheel['social-links']['6'] ); ?>" class="youtube"><i class="fa fa-youtube"></i></a></li>
                        <?php endif; ?>
                        <?php if( $bizwheel['social-links']['7'] ) : ?>
                            <li><a href="<?php echo esc_url( $bizwheel['social-links']['7'] ); ?>" class="skype"><i class="fa fa-skype"></i></a></li>
                        <?php endif; ?>
                        <?php if( $bizwheel['social-links']['8'] ) : ?>
                            <li><a href="<?php echo esc_url( $bizwheel['social-links']['8'] ); ?>" class="google"><i class="fa fa-google-plus"></i></a></li>
                        <?php endif; ?>
                        <?php if( $bizwheel['social-links']['9'] ) : ?>
                            <li><a href="<?php echo esc_url( $bizwheel['social-links']['9'] ); ?>" class="dribbble"><i class="fa fa-dribbble"></i></a></li>
                        <?php endif; ?>
                        <?php if( $bizwheel['social-links']['10'] ) : ?>
                            <li><a href="<?php echo esc_url( $bizwheel['social-links']['10'] ); ?>" class="tumblr"><i class="fa fa-tumblr"></i></a></li>
                        <?php endif; ?>
					</ul>	
				    <?php endif; ?>
					<?php if( ! $bizwheel['top-bar-btn-text'] == '' && ! $bizwheel['top-bar-btn-link'] == '' ) : ?>
						<div class="button">
							<a href="<?php echo esc_html( $bizwheel['top-bar-btn-link'] ); ?>" class="bizwheel-btn"><?php echo esc_html( $bizwheel['top-bar-btn-text'] ); ?></a>
						</div>
				    <?php endif; ?>
				</div>
			</div>
		</div>
	</div>
</div>
<!--/ End Topbar -->
<?php endif; ?>
